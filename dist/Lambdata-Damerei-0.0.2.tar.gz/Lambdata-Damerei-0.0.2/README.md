Lambdata-Damerei
A library of DS helper functions

